# PP-IPG

Lifelong Visible-Infrared Person Re-Identification with Prompt Pool and Instance-level Prompt Generator

links:  https://dl.acm.org/doi/10.1145/3731715.3733373

run Continual_train_l2pdap.py to start training